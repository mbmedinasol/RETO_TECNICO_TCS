package com.examen.persona.events;

import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.examen.persona.DTO.ClienteDTO;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class ClienteProducer {

    private final KafkaTemplate<String, ClienteDTO> kafkaTemplate;
    
    public void enviarCliente(ClienteDTO clienteDTO) {
        kafkaTemplate.send("clientes-topic", clienteDTO);
    }

}
