package com.examen.persona.DTO;

import lombok.Data;

@Data
public class RespuestaDTO {
    String mensaje;
}
