package com.examen.movimiento.dto;

import lombok.Data;

@Data
public class RespuestaDTO {

	private String mensaje;
}
