package com.examen.movimiento.events;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.examen.movimiento.dto.ClienteDto;

@Service
public class MovimientoConsumer {

    @KafkaListener(topics = "clientes-topic", groupId = "movimiento-group")
    public void recibirCliente(ClienteDto clienteDto) {
        System.out.println("Consumed message: " + clienteDto);
    }   

}
