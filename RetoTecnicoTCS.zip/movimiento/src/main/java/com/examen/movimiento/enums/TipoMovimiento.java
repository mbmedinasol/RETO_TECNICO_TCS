package com.examen.movimiento.enums;

public enum TipoMovimiento {
    RETIRO, DEPOSITO
}
