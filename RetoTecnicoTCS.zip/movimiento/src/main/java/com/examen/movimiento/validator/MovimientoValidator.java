package com.examen.movimiento.validator;

import org.springframework.stereotype.Component;

@Component
public class MovimientoValidator {
    
}
