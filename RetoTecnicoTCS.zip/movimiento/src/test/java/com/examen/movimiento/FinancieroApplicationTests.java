package com.examen.movimiento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinancieroApplicationTests {

	@Test
	void contextLoads() {
	}

}
